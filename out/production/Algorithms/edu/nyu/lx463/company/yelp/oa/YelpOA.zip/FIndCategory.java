package edu.nyu.lx463.company.yelp.oa;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LyuXie on 8/11/17.
 */
public class FIndCategory {
    static class BusinessInfo{
        int id;
        List<String> categories;
        BusinessInfo(int id, List<String> categories) {
            this.id = id;
            this.categories = new ArrayList<>();
        }
    }

    public static List<Integer> find(List<BusinessInfo> list, String s1, String s2) {
        List<Integer> result = new ArrayList<>();
        for (BusinessInfo b : list) {
            if (b.categories.contains(s1) && b.categories.contains(s2)) {
                result.add(b.id);
            }
        }

        return result;
    }
    public static void main(String[] args) {
    }
}
