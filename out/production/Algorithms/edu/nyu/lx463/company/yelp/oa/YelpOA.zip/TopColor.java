package edu.nyu.lx463.company.yelp.oa;

import java.util.*;

/**
 * Created by LyuXie on 8/9/17.
 */
public class TopColor {
    public static List<String> topColor(List<List<String>> colorArray) {
        if (colorArray == null || colorArray.size() == 0) {
            return null;
        }

        List<String> result = new ArrayList<>();
        int max = 0;
        Map<String, Integer> map = new HashMap<>();
        for (List<String> list : colorArray) {
            for (String s : list) {
                Integer count = map.get(s);
                if (count == null) {
                    map.put(s, 1);
                }else {
                    map.put(s, count + 1);
                }
                max = Math.max(map.get(s), max);
            }
        }

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() == max) {
                result.add(entry.getKey());
            }
        }

        Collections.sort(result, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        });

        return result;




    }
    public static void main(String[] args) {
        List<List<String>> colors = new ArrayList<>();
        List<String> color1 = new ArrayList<>();
        List<String> color2 = new ArrayList<>();
        List<String> color3 = new ArrayList<>();
        color1.add("red");
        color1.add("green");
        color1.add("green");
        color2.add("black");
        color2.add("blue");
        color2.add("black");
        color3.add("red");
        color3.add("yellow");
        color3.add("yellow");
        colors.add(color1);
        colors.add(color2);
        colors.add(color3);
        System.out.println(topColor(colors));
    }
}
