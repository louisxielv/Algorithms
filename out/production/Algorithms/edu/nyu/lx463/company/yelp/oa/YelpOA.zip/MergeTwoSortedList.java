package edu.nyu.lx463.company.yelp.oa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by LyuXie on 8/10/17.
 */
public class MergeTwoSortedList {
    static class BusinessInfo{
        int id;
        int numOfReviews;
        BusinessInfo (int id, int numOfReviews) {
            this.id = id;
            this.numOfReviews = numOfReviews;
        }
    }

    public static List<BusinessInfo> merge(List<BusinessInfo> list1, List<BusinessInfo> list2) {
        if (list1 == null && list2 == null) {
            return null;
        }

        if (list1 == null) {
            return list2;
        }

        if (list2 == null) {
            return list1;
        }

        List<BusinessInfo> result = new ArrayList<>();
        int p1 = 0;
        int p2 = 0;

        while (p1 < list1.size() && p2 < list2.size()) {
            if (list1.get(p1).numOfReviews >= list2.get(p2).numOfReviews) {
                result.add(list1.get(p1));
                p1++;
            }else if (list1.get(p1).numOfReviews < list2.get(p2).numOfReviews) {
                result.add(list2.get(p2));
                p2++;
            }
        }

        while (p1 < list1.size()) {
            result.add(list1.get(p1));
            p1++;
        }

        while (p2 < list2.size()) {
            result.add(list2.get(p2));
            p2++;
        }

        return result;
    }

    public static void main(String[] args) {
        List<BusinessInfo> list1 = Arrays.asList(new BusinessInfo(1, 800),
                new BusinessInfo(3, 700), new BusinessInfo(5, 100));
        List<BusinessInfo> list2 = Arrays.asList(new BusinessInfo(2, 500),
                new BusinessInfo(4, 300), new BusinessInfo(6, 50));
        List<BusinessInfo> result = merge(list1, list2);
        for(BusinessInfo business: result) {
            System.out.print(business.id + ", " + business.numOfReviews);
            System.out.println();
        }
    }
}
