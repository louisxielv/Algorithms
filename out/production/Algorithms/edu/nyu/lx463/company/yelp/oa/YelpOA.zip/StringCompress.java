package edu.nyu.lx463.company.yelp.oa;

/**
 * Created by LyuXie on 8/10/17.
 */
public class StringCompress {
    public static String compress(String s) {
        if (s == null || s.length() == 0 || s.length() == 1) {
            return s;
        }

        char[] array = s.toCharArray();
        int slow = 0;
        for (int fast = 0; fast < array.length; fast++) {
            int count = 0;
            char c = array[fast];
            while (fast < array.length && array[fast] == c) {
                count++;
                fast++;
            }

            if (count > 1) {
                array[slow++] = c;
                array[slow++] = (char)('0' + count);
            }else {
                array[slow++] = c;
            }

            fast--;
        }

        return new String(array, 0, slow);
    }

    public static void main(String[] args) {
        System.out.print(compress(""));
    }
}
