package edu.nyu.lx463.company.yelp.oa;

/**
 * Created by LyuXie on 8/11/17.
 */
public class ReduceE {
    public static String reduce(String s) {
        if (s == null || s.length() == 0){
            return s;
        }

        char[] array = s.toCharArray();

        int slow = 0;

        for (int i = 0; i < array.length; i++) {
            if(array[i] == 'e') {
                array[slow++] = 'e';
                while(i < array.length && array[i] == 'e') {
                    i++;
                }
                i--;
            }else {
                array[slow++] = array[i];
            }
        }

        return new String(array, 0, slow);
    }

    public static void main(String[] args) {
        System.out.print(reduce("e"));
    }

}
