package edu.nyu.lx463.company.yelp.oa;

import java.util.*;

/**
 * Created by LyuXie on 8/10/17.
 */
public class SortBusinessByRating {
    static class Business{
        int id;
        int rating;
        Business(int id, int rating) {
            this.id = id;
            this.rating = rating;
        }
    }

    public static List<Business> sort(List<Business> list) {
        Collections.sort(list, new Comparator<Business>() {
            @Override
            public int compare(Business o1, Business o2) {
                if (o1.rating == o2.rating) {
                    return 0;
                }

                return o1.rating > o2.rating ? -1 : 1;
            }
        });

        return list;
    }

    public static void main(String[] args) {
        List<Business> list = new ArrayList<>();
        list.addAll(Arrays.asList(new Business(1,5), new Business(2,3), new Business(3,4), new Business(4,5), new Business(5,5), new Business(6,4), new Business(7,3)));
        List<Business> result = SortBusinessByRating.sort(list);
        for(Business business: result) {
            System.out.print(business.id + ", " + business.rating);
            System.out.println();
        }
    }

}
