package edu.nyu.lx463.company.yelp.oa;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by LyuXie on 8/11/17.
 */
public class MinIndex {
    public static String minIndexSum(List<String> l1, List<String> l2) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < l1.size(); i++) {
            map.put(l1.get(i), i);
        }

        int min = Integer.MAX_VALUE;
        String result = "YelpWhich";
        for (int i = 0; i < l2.size(); i++) {
            Integer index = map.get(l2.get(i));
            if (index == null) {
                continue;
            }else {
                int indexSum = i + index;
                if (indexSum < min) {
                    min = indexSum;
                    result = l2.get(i);
                }
            }
        }

        return result;
    }

    public static void main(String[] args) {
        List<String> l1 = Arrays.asList("EI Farolito", "Japa Curry", "Eatsa");
        List<String> l2 = Arrays.asList("Japa Curry", "Eatsa", "Ayola", "Working Girls");
        List<String> l3 = Arrays.asList("EI Farolito", "Japa Curry");
        List<String> l4 = Arrays.asList("Ayola", "Working Girls");
        System.out.print(minIndexSum(l3, l4));
    }
}
